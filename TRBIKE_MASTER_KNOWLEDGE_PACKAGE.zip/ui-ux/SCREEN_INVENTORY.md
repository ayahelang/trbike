# SCREEN INVENTORY
Passenger: Splash, Auth, Verification, Home/Map, Pickup, Quote, Driver Selection, Tracking, Cancel, Payment, Complete, Tip, Rating, History, Promo, Safety.
Driver: Auth, KYC, Vehicle, Dashboard, Online, Incoming Order, Active Ride, Cancellation Alert, Earnings, Ledger, Tips, Ratings, Battery, Scan, Safety.
Admin: Dashboard, Users, Drivers, KYC, Vehicles, Fare Rules, Benchmarks, Rides, Ledger, Compensation, Promo, Fraud, Complaints, Analytics.
