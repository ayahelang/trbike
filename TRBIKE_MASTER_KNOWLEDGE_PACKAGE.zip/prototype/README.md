# INCLUDED PROTOTYPE
Previously generated GitHub Pages + Supabase MVP.
Known notes: fare parameters are hardcoded; formula does not enforce 20% benchmark; production financial calculations should be server-side; original `js/config.js` has a `TRIKE_CONFIG` naming typo that should be corrected when reopened.
