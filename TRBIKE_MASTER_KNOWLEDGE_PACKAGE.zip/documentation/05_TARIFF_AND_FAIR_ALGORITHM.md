# TRBIKE — TARIFF & FAIR ALGORITHM

Prototype parameters pernah memakai contoh: Pertamax Rp12.500/liter, 40 km/l, base Rp2.500, service 17%, tax 11%, maintenance 10%, labor 10%, health 10%, old-age 5%, charity 2,5%, food 7,5%. **Bukan tarif produksi final.**

Formula prototype lama:
fuel/km = fuel_price / efficiency
fuel trip = trip_km × fuel/km
fuel pickup = pickup_km × fuel/km
operating base = base + fuel trip + fuel pickup
driver pool = operating base × sum(pool percentages)
service = (operating base + driver pool) × service%
class multiplier → tax → rounding.
Driver gross = total - service - tax.

Formula ini belum menjamin target 20% lebih murah.

Target konseptual:
`target_max = cheapest_valid_competitor_price × 0.80`

Tetapi juga perlu constraint:
- passenger_total <= benchmark target;
- driver_right >= minimum viable earning;
- platform_net >= minimum viable platform economics;
- tax/legal requirements.

Jika semua constraint tidak mungkin dipenuhi, sistem harus membuat exception yang terlihat/admin-auditable, bukan manipulasi tersembunyi.

Fare snapshot wajib menyimpan city, class, distance, pickup, fuel price, rule version, benchmark version, formula version.

Final authoritative fare wajib server-side.
