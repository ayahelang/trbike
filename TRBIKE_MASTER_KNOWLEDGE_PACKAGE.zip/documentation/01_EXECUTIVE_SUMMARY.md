# TRBIKE — EXECUTIVE SUMMARY
TRBIKE adalah konsep transportasi online roda dua dengan prinsip **terbaik untuk driver dan penumpang**.

Tujuan:
- harga kompetitif dan transparan;
- penerimaan driver layak;
- biaya perjalanan nyata diperhitungkan;
- keselamatan passenger/driver;
- fairness distribusi order;
- arsitektur client-server;
- dapat menjadi prototype dan proyek skripsi Teknik Informatika.

Fitur utama: booking, matching, pickup-distance pricing, kelas kendaraan, KYC, vehicle verification, ETA, traffic, cancellation compensation, tip, rating/accountability, direct phone scan, driver-phone battery eligibility, wallet/ledger, admin, anti-fraud.

Judul skripsi yang dipilih:
**“Perancangan dan Pengembangan Sistem Transportasi Online TRBIKE Berbasis Arsitektur Client–Server dan Algoritma Tarif Adil”**
