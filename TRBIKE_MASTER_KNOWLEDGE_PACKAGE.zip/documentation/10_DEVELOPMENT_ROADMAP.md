# TRBIKE — ROADMAP

V0 Knowledge/prototype.
V1 Reliable server-side fare engine + city rules + benchmark.
V2 Maps/realtime/ETA/traffic.
V3 Matching + fairness + battery.
V4 Payment/wallet/immutable ledger/tips.
V5 KYC/vehicle/safety.
V6 Cancellation compensation/congestion.
V7 Direct scan 1 km + fairness queue.
V8 Admin/fraud/analytics.
V9 Thesis evaluation.
V10 Production readiness: legal/privacy, security audit, load testing, monitoring, DR.
