# TRBIKE — UI/UX SPECIFICATION

## Passenger screens
Splash → Login/Register → Verification → Home/Map → Pickup/Destination → Fare Quote → Driver Selection → Tracking → Cancellation Confirmation → Payment → Trip Complete → Tip → Rating/Comment → History → Promotions → Safety.

Fare card wajib menjelaskan trip distance, pickup distance, service class, ETA, komponen biaya, fee, tax, total.

Driver card menampilkan foto, nama, rating/accountability, vehicle photo, class, pickup distance, ETA, price.

Cancellation dialog harus menyebut jarak pickup yang sudah ditempuh dan estimasi kompensasi.

## Driver screens
Login/KYC → Vehicle registration/check → Dashboard → Online/Offline → Incoming Order → Active Ride → Cancellation Alert → Earnings/Wallet → Ledger → Tips/Ratings → Battery Readiness → Scan/Queue → Safety.

Cancellation alert:
**ORDER DIBATALKAN — Kompensasi pickup: Rp... — BBM: Rp... — Effort: Rp... — Waktu: Rp...**

Gunakan wording **Hak/Penerimaan Driver dari Pembayaran Penumpang**, bukan “gaji TRBIKE”.

## Admin
Dashboard, users, KYC, vehicles, fare rules, benchmarks, rides, ledger, compensation, promotions, security/fraud, complaints, analytics.

UX: no hidden fees, no misleading ETA, no forced tip, clear cancellation consequence, clear verification status, accessible buttons, low-bandwidth states.
