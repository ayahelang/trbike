# TRBIKE — FEATURE SPECIFICATION

## Passenger
Login/register; profile; KYC; home/map; pickup/destination; fare quote; service class; driver selection; skip distant driver; realtime tracking; ETA; traffic; cancel; payment; tip; rating/comment; history; promotions; safety/report.

## Driver
Login/register; KYC; vehicle registration; vehicle photo verification; online/offline; incoming order; accept/reject; navigation; battery readiness; cancellation alert; earnings; driver pool ledger; tips; ratings; scan queue; safety/report.

## Admin
Users, drivers, KYC, vehicles, fare rules, city rules, competitor benchmark, rides, payments/ledger, compensation, promotions, complaints, fraud/security, analytics.

## Core flows
Passenger requests → route/distance → candidate drivers → pickup distance → fare engine → quote → accept → realtime ride → complete → payment → ledger → tip/rating.

## Rating/accountability
Rating tidak hanya bintang; dapat mencakup safety, punctuality, vehicle condition, courtesy, route adherence. Accountability passenger dipengaruhi verification/history.

## Cancellation compensation
Concept: `fuel_pickup + driver_effort + time_loss`, dengan threshold/cap/evidence/fraud rules.

## Notifications
New ride, accepted, approaching, cancelled, compensation, payment, tip, safety. Critical cancellation harus sangat terlihat.
