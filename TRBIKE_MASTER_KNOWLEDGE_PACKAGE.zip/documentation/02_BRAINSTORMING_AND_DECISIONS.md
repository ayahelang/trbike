# TRBIKE — BRAINSTORMING & DECISIONS

## Prinsip
Fairness, transparency, driver safety, passenger safety, cost-based pricing, auditability, privacy, simplicity, scalability.

## Tarif
Komponen yang pernah dibahas: BBM Pertamax/km, maintenance, driver effort/labor, health savings, old-age savings, charity, food savings, platform fee, tax/PPN.

**Driver pool bukan gaji TRBIKE.** Itu hak/penerimaan driver dari pembayaran penumpang. Persentase kesehatan/hari tua/charity/makanan adalah konsep pengelolaan uang driver.

Target bisnis yang pernah ditetapkan: diupayakan sekitar **20% lebih murah daripada kompetitor termurah** pada kondisi pembanding yang sama. Ini harus didefinisikan dan diuji, bukan dianggap angka otomatis.

## Pickup
Biaya driver menuju pickup ikut diperhitungkan. Passenger diberi tahu jika driver jauh dan dapat Skip.

## Cancel pickup jauh
Jika passenger membatalkan setelah driver menempuh jarak pickup tertentu, kompensasi dapat mencakup BBM + effort/uang capek + waktu hilang. Tidak untuk mengompensasi mengemudi sengaja lambat. Congestion dapat diberi bukti foto ber-geotag.

Driver menerima notifikasi cancellation/kompensasi dengan suara dan getaran jika platform mengizinkan.

## Verification
Passenger belum terverifikasi dapat dibatasi dari benefit tertentu dan pickup lokasi/waktu berisiko. Passenger terverifikasi mendapat benefit lebih dan accountability lebih tinggi.

Driver wajib verifikasi kendaraan sebelum online; foto harus jelas dan nomor polisi terlihat. Kelas premium dapat menampilkan foto kendaraan ke passenger dan passenger dapat reject jika tidak sesuai.

## Scan
Direct phone scan untuk perjalanan pendek: radius 1 km; jika banyak driver, nearest driver diprioritaskan; tie-break memakai longest-since-last-scan agar adil di pangkalan.

## Battery
Yang dipantau adalah **baterai HP driver**, bukan aki motor. Sistem memperkirakan kemampuan HP mempertahankan komunikasi untuk pickup + trip. Charging dapat dianggap aman sesuai kebijakan.

## Tips
Tip driver dicatat dan aktivitas tip dapat menjadi sinyal reward/promo/surprise gift.

## Traffic/ETA
ETA berdasarkan kecepatan normal/legal. Map menunjukkan congestion. Passenger dapat cancel karena ETA, tetapi kompensasi pickup tetap mengikuti kebijakan jarak yang telah ditempuh.
