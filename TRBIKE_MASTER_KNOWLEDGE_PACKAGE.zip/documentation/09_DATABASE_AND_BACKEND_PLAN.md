# TRBIKE — DATABASE & BACKEND

Prototype tables:
profiles, drivers, vehicles, vehicle_online_checks, rides, fare_rules, driver_pool_ledger, payments, tips, customer_activity, driver_scan_history, ratings, cancellation_compensation, congestion_evidence, security_events.

Production candidates:
identity_verifications, vehicle_verifications, fare_benchmarks, fare_quotes, fare_rule_versions, ledger_accounts, ledger_transactions, ledger_entries, payouts, notifications, driver_locations, ride_events, fraud_cases, disputes, promo_campaigns, reward_events.

Server functions:
create_quote, create_ride, accept_ride, cancel_ride, finalize_ride, calculate_compensation, create_tip, settle_payment, record_ledger_transaction, evaluate_battery, evaluate_scan_priority.

Prototype RLS needs tightening; requested rides must not be globally readable by every authenticated user.
