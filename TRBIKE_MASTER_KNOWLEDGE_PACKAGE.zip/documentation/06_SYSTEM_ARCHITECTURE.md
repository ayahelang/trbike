# TRBIKE — SYSTEM ARCHITECTURE

Passenger Client / Driver Client
→ API/Application Layer
→ Auth/KYC, Fare Engine, Matching, Ride State Machine, Payment, Notification, Safety/Fraud
→ PostgreSQL/Supabase
→ realtime/external services (maps, payment, push, KYC).

Client: UI/input/map/local state.
Server: authorization, fare, matching, wallet, ledger, compensation, KYC decisions, fraud, audit.

Ride states: requested → accepted → driver_arriving → driver_arrived → in_trip → completed/cancelled.

Production financial operations harus server-side dan menggunakan immutable ledger.

Security: RLS, RBAC, least privilege, no service-role key in frontend, audit log, rate limiting, signed uploads, fraud controls.

Privacy: identity documents minimized and tightly controlled.
