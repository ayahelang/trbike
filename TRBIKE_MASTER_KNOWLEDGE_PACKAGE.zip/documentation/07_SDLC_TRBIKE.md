# TRBIKE — SDLC

1. **Planning:** problem, objective, scope, fairness principles.
2. **Requirements Analysis:** passenger/driver/admin, fare, safety, verification, payment, rating, cancellation.
3. **System Design:** client-server, DB, API, algorithms, security, UI/UX, state machine.
4. **Development:** HTML/CSS/JS + Supabase prototype; production backend/mobile/web later.
5. **Testing:** functional, algorithm, security, performance, UX.
6. **Deployment:** prototype via GitHub Pages; production infrastructure later.
7. **Maintenance:** fare rules, bugs, security, regulation, performance.

SDLC dapat menjadi kerangka pengembangan untuk skripsi, disertai metode pengujian/evaluasi akademik sesuai pedoman kampus.
