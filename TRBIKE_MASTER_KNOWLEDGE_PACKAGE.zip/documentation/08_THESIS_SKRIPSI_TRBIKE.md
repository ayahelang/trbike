# TRBIKE — SKRIPSI

## Judul
**Perancangan dan Pengembangan Sistem Transportasi Online TRBIKE Berbasis Arsitektur Client–Server dan Algoritma Tarif Adil**

## BAB I — Pendahuluan
Latar belakang, identifikasi/batasan masalah, rumusan masalah, tujuan, manfaat, sistematika.

## BAB II — Landasan Teori
Sistem informasi, transportasi online, client-server, database, algoritma, fair pricing, GPS/geolocation, matching, UI/UX, keamanan, SDLC, testing.

## BAB III — Metodologi
Pendekatan penelitian, SDLC, requirement gathering, analisis, desain, implementasi, testing, evaluasi.

## BAB IV — Analisis & Perancangan
Kebutuhan fungsional/nonfungsional, use case, activity, sequence, arsitektur, ERD, UI/UX, algoritma tarif, matching, cancellation, scan fairness.

## BAB V — Implementasi
Frontend, backend, database, auth, fare engine, ride flow, driver flow, implementasi prototype.

## BAB VI — Pengujian & Hasil
Functional testing, algorithm scenarios, security, UX, benchmark comparison, fairness analysis.

## BAB VII — Kesimpulan & Saran
Kesimpulan, pencapaian tujuan, keterbatasan, pengembangan.

## Research questions
Bagaimana merancang client-server TRBIKE? Bagaimana merancang tarif transparan/adil? Bagaimana pickup distance dan cancellation dimasukkan? Bagaimana verification/rating/safety? Bagaimana menguji sistem?

Klaim “20% lebih murah” harus dibuktikan dengan dataset benchmark yang terdokumentasi.
