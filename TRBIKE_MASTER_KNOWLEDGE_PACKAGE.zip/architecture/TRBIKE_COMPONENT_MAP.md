# COMPONENT MAP
Passenger/Driver Clients → API/Application → Auth/KYC + Fare + Matching + Ride State + Payment + Notification + Safety/Fraud → PostgreSQL/Supabase → external Maps/Payment/Push/KYC.
